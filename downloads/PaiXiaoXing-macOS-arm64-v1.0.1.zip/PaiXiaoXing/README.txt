派小星 macOS 桌面版

双击 派小星.app 运行。拖到屏幕边缘松手即可吸附，悬停查看本地 Codex 用量。

可选启用随 Codex 启动：在此目录运行 bash 启用Codex联动.sh
关闭：bash 关闭Codex联动.sh

此包支持 Apple Silicon / macOS 13+，使用本地签名，未经 Apple 公证。
源码与说明：https://github.com/ZzzZTtT0/pai-xiao-xing
