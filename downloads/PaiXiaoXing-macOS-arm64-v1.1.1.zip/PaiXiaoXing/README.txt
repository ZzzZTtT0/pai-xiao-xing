派小星 v1.1.1 · macOS 桌面宠物

双击 派小星.app 运行。自动发现默认 Codex 和 Cockpit Tools 多开实例的本地会话。
右键 → 会话数据，可以选择并锁定一个实例的会话，或跟随最近活跃会话。
任务执行时头顶显示简要关键操作；右键“显示任务气泡”可开关。

可选随 Codex 启动：bash 启用Codex联动.sh
关闭：bash 关闭Codex联动.sh

支持 Apple Silicon / macOS 13+；本地签名，未经 Apple 公证。
源码与说明：https://github.com/ZzzZTtT0/pai-xiao-xing
